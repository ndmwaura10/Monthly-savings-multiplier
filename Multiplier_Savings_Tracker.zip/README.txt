MULTIPLIER SAVINGS TRACKER

1. Open index.html in a browser.
2. Choose the month and enter your multiplier.
3. Tap Save / Update Month.
4. Tap each day after making the payment.
5. For a phone home-screen app, the files need to be hosted at a web address (HTTPS). Then open that address in Chrome and use "Add to Home screen".

Example:
Multiplier 18:
Day 1 = KSh 18
Day 2 = KSh 36
Day 10 = KSh 180
Day 30 = KSh 540

Data is stored locally in the browser. Use Backup data before clearing browser data or moving devices.
